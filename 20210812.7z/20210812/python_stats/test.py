# !/usr/bin/python
# -*- coding: utf-8 -*-
"""
@author: sumex
@software: PyCharm
@time: 2021/8/12 16:27
@file: test.py
"""
import numpy as np

# a = np.arange(9).reshape(3,3)
# b = np.arange(9).reshape(3,3)
#
# print(a)
# print(b)
#
# c = np.where(a > 5 & b < 10, 1, 0)
#
# print(c)
import torch

a = torch.arange(9).reshape(3,3)
b = torch.arange(9).reshape(3,3)

ones = torch.ones_like(a)
zeres = torch.zeros_like(a)

print(a)
print(b)

c = torch.where((a == 3) & ( b == 3), ones, zeres)

print(c)


